package Modelo;

/**
 * Clase que corresponde a el usuario cliente del sistema, contiene los
 * atributos de un cliente.
 *
 * @author Samantha Caamal.
 */
public class ClienteModelo extends Usuario {

    /**
     * Direccion del cliente.
     */
    public String direccion;
    /**
     * Telefono del cliente.
     */
    public int telefono;
    /**
     * Edad del cliente.
     */
    public int edad;
    /**
     * Contador para el ID.
     */
    public int contador = 1000;

    /**
     * Constructor de la clase.
     *
     * @param ID contiene el ide del cliente
     * @param nombre contiene el nombre del cliente.
     * @param contrasenia contiene la contrasenia de la cuenta del cliente.
     * @param direccion contiene la direccion del domicilio del cliente.
     * @param telefono contiene el telefono del cliente.
     * @param edad contiene la edad del cliente.
     */
    public ClienteModelo(String ID, String nombre, String contrasenia, String direccion, int telefono, int edad) {
        super(ID, nombre, contrasenia);
        this.direccion = direccion;
        this.telefono = telefono;
        this.edad = edad;
    }
    /**
     * Constructor de la clase.
     *
     * @param ID contiene le id del cliente
     * @param nombre contiene el nombre del cliente.
     * @param direccion contiene la direccion del domicilio del cliente.
     * @param telefono contiene el telefono del cliente.
     */
    public ClienteModelo(String ID, String nombre, int telefono, String direccion) {
        super(ID, nombre);
        this.telefono = telefono;
        this.direccion = direccion;
    }

    //Metodos get y set
    /**
     * Metodo para obtener la direccion del cliente.
     *
     * @return direccion del cliente.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Metodo para establecer la direccion del cliente.
     *
     * @param direccion contiene una cadena con la direccion del cliente.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Metodo para obtener el telefono del cliente.
     *
     * @return telefono del cliente.
     */
    public int getTelefono() {
        return telefono;
    }

    /**
     * Metodo para establecer el telefono del cliente.
     *
     * @param telefono contiene el telefono del cliente.
     */
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    /**
     * Metodo para obtener la edad del cliente.
     *
     * @return edad del cliente.
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Metodo para establecer la edad del cliente.
     *
     * @param edad contiene un numero entero que representa la edad.
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    //Metodos abstractos
    /**
     * Metodo heredado para establecer la contrasenia del cliente.
     *
     * @param contrasenia contiene una cadena ingresada por el cliente.
     */
    @Override
    public void setContrasenia(String contrasenia) {
        super.setContrasenia(contrasenia);
    }

    /**
     * Metodo heredado para obtener la contrasenia del cliente.
     *
     * @return contrasenia contiene un string.
     */
    @Override
    public String getContrasenia() {
        return super.getContrasenia();
    }

    /**
     * Metodo heredado para establecer el nombre del cliente.
     *
     * @param nombre contiene un string.
     */
    @Override
    public void setNombre(String nombre) {
        super.setNombre(nombre);
    }

    /**
     * Metodo heredado para obtener el nombre del cliente.
     *
     * @return nombre del cliente.
     */
    @Override
    public String getNombre() {
        return super.getNombre();
    }

    /**
     * Metodo heredado para establecer el ID del cliente
     *
     * @param ID contiene un string.
     */
    @Override
    public void setID(String ID) {
        super.setID(ID);
    }

    /**
     * Metodo heredado para obtener el ID del cliente.
     *
     * @return ID con la clave del cliente.
     */
    @Override
    public String getID() {
        return "C" + super.getID();
    }

    @Override
    public String toString() {
        return "Cliente(" + "ID: " + getID() + ", Nombre: "+nombre+", Dir: " + direccion + ", telefono: " + telefono + ")";
    }

}
