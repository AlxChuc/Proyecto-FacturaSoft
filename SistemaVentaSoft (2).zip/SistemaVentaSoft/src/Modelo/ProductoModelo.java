package Modelo;

/**
 * Clase para poder crear productos, se obtiene el ID, descripcion general,
 * piezas en existencia, precio unitario del producto.
 * @author Samantha Caamal.
 */
public class ProductoModelo {
    /**
     * ID del producto.
     */
    public String idProducto;
    /**
     * Descripcion general del producto.
     */
    public String descripcion;
    /**
     * Piezas disponibles del producto.
     */
    public int cantidad;
    /**
     * Precio unitario del  producto.
     */
    public double precioUnitario;
    /**
     * Precio total por la cantidad de productos comprados.
     */
    public double importe;
    /**
     * Constructo vacio de la clase.
     */
    public ProductoModelo() {
    }
    /**
     * Contructor de la clase.
     * @param idProducto contiene la clave unica del producto.
     * @param descripcion contiene datos del producto como nombre, modelo, etc.
     * @param cantidad contiene las piezas en existencia del producto.
     * @param precioUnitario contiene el precio unitario del producto.
     */
    public ProductoModelo(String idProducto, String descripcion, int cantidad, double precioUnitario) {
        this.idProducto = idProducto;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }
    /**
     * Contructor de la clase.
     * @param idProducto contiene la clave unica del producto.
     * @param descripcion contiene datos del producto como nombre, modelo, etc.
     * @param cantidad contiene las piezas en existencia del producto.
     * @param precioUnitario contiene el precio unitario del producto.
     * @param importe contiene el subtotal por los productos.
     */
//    public ProductoModelo(String idProducto, String descripcion, int cantidad, double precioUnitario, double importe) {
//        this.idProducto = idProducto;
//        this.descripcion = descripcion;
//        this.cantidad = cantidad;
//        this.precioUnitario = precioUnitario;
//    }
    //Metodos get y set
    /**
     * Metodo para obtener la clave unica del producto.
     * @return ID del producto.
     */
    public String getIdProducto() {
        return "P" + idProducto;
    }
    /**
     * Metodo para establecer la clave unica del producto.
     * @param idProducto contiene una cadena con el ID del producto.
     */
    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }
    /**
     * Metodo para obtener la descripcion del producto.
     * @return descripcion del producto.
     */
    public String getDescripcion() {
        return descripcion;
    }
    /**
     * Metodo para establecer la descripcion del producto.
     * @param descripcion contiene una cadena con la descripcion del producto.
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    /**
     * Metodo para obtener el numero de piezas disponibles del producto.
     * @return piezas de existencia.
     */
    public int getCantidad() {
        return cantidad;
    }
    /**
     * Metodo para establecer la piezas existentes del producto.
     * @param cantidad contiene un numero entero de piezas existentes.
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    /**
     * Metodo para obtiene el precio unitario del producto.
     * @return precio unitario del producto.
     */
    public double getPrecioUnitario() {
        return precioUnitario;
    }
    /**
     * Metodo para establecer el precio unitario del producto.
     * @param precioUnitario contiene un double con el precio del producto.
     */
    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
    /**
     * Metodo que obtiene el importe final a pagar por el producto.
     * @return importe total a pagar.
     */
    public double getImporte() {
        return importe;
    }
    /**
     * Metodo para establecer el importe total del producto.
     * @param importe contiene un double con el importe total.
     */
    public void setImporte(double importe) {
        this.importe = importe;
    }
    /**
     * Metodo para poder escribir la informacion del producto.
     * @return una cadena con los datos del producto.
     */
    @Override
    public String toString() {
        return this.idProducto + "@" + this.descripcion + "@" + this.cantidad + "@" + this.precioUnitario;
    }
}
