package Excepciones;

/**
 * Clase que corresponde a errores de patron.
 * @author Samantha Caamal.
 */
public class NoPattern extends RuntimeException{
    /**
     * Clase que genera un mensaje que desea el programador.
     * @param mensaje contiene una cadena.
     */
    public NoPattern(String mensaje){
        super(mensaje);
    }
}
