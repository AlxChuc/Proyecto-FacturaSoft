/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Alex
 */
public class NotaModelo {

    /**
     * El numero de la nota.
     */
    private int numNota;
    /**
     * actualizacion del numero de la nota.
     */
    public static int staticValue;
    /**
     * arreglo de productos.
     */
    private ArrayList<ProductoModelo> productos;
    /**
     * la fecha (para poner la de hoy).
     */
    private String fecha;
    /**
     * empleado a quien pertenece la nota.
     */
    private EmpleadoModelo empleado;
    /**
     * Total de la venta.
     */
    private double totalPagado;

    
    public NotaModelo(ArrayList<ProductoModelo> vendidos, EmpleadoModelo empleado) {
        this.numNota = staticValue;
        this.empleado = empleado;
        this.productos = vendidos;
        this.fecha = Calendar.getInstance().getTime().toString();
    }

//    public NotaModelo(int idNota, ArrayList<ProductoModelo> vendidos, EmpleadoModelo empleado, String fecha, double totalPagado) {
//        this.numNota = staticValue;
//        this.empleado = empleado;
//        this.productos = vendidos;
//        this.fecha = fecha;
//        this.totalPagado = totalPagado;
//    }

    public NotaModelo(ArrayList<ProductoModelo> productos,int numero, String fecha) {
        this.numNota = numero;
        this.productos = productos;
        this.fecha = fecha;
        this.empleado = null;
    }
/** establece el numero de la nota
     * @param numNota int
 */
    public void setNumNota(int numNota) {
        this.numNota = numNota;
    }

    /**
     * establece el contador de la nota
     * @param staticValue int
     */
    public static void setStaticValue(int staticValue) {
        NotaModelo.staticValue = staticValue;
    }

    /**
     * obtiene el total a pagar
     * @return double
     */
    public double getTotalPagado() {
        return totalPagado;
    }

    /**
     * establece los productos de la nota
     * @param productos recibe ArrayList de tipo ProductoModelo
     */
    public void setProductos(ArrayList<ProductoModelo> productos) {
        this.productos = productos;
    }

    /**
     * establece la fecha
     * @param fecha string
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    /**
     * establece el empleado
     * @param empleado EmpleadoModelo
     */
    public void setEmpleado(EmpleadoModelo empleado) {
        this.empleado = empleado;
    }

    /**
     * estableec el total a pagar
     * @param totalPagado double
     */
    public void setTotalPagado(double totalPagado) {
        this.totalPagado = totalPagado;
    }
    /**
     * obtiene el numero de la nota
     *
     * @return int, numero de la nota
     */
    public int getNumNota() {
        return numNota;
    }

    /**
     * obtiene los productos
     * @return Array de tipo ProductoModelo
     */
    public ArrayList<ProductoModelo> getProductos() {
        return productos;
    }

    /**
     * aumenta el valor de la variable estatica
     */
    public void masUno() {
        staticValue++;
    }

    /**
     * obtiene el empleado de la nota
     *
     * @return EmpleadoModelo, quien hizo la nota
     */
    public EmpleadoModelo getEmpleado() {
        return empleado;
    }

    /**
     * obtiene la fecha de hoy
     *
     * @return Date, la fecha de hoy
     */
    public String getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return this.numNota + ";" + this.productos + ";" + this.fecha;
    }
}
