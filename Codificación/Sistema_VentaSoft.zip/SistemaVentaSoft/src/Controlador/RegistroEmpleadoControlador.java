package Controlador;

import Excepciones.CampoVacio;
import Excepciones.NoCoincidenciaContrasenia;
import Modelo.Archivo;
import Modelo.EmpleadoModelo;
import Vista.RegistroEmpleadoVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * Clase que controla la ventana de registro de un nuevo empleado.
 *
 * @author Samantha Caamal
 */
class RegistroEmpleadoControlador implements ActionListener {

    /**
     * Ventana del controlador.
     */
    private RegistroEmpleadoVista ventana;
    /**
     * Boton para guardar el nuevo empleado.
     */
    private JButton guardar;
    /**
     * Boton para cancelar la operacion.
     */
    private JButton cancelar;
    /**
     * Cadena con el nombre del empleado.
     */
    private String nombre;
    /**
     * Cadena con el ID del empleado.
     */
    private String id;
    /**
     * Edad del empleado.
     */
    private int edad;
    /**
     * Contrasenia de la cuenta del empleado.
     */
    private String contrasenia;
    /**
     * Confirmacion de la contrasenia ingresada.
     */
    private String contrasenia2;
    /**
     * Instancia del objeto empleado.
     */
    private EmpleadoModelo empleado;

    /**
     * Contructor de la clase.
     *
     * @param vista contiene la ventana a controlar.
     * @param nextID contiene el ID del nuevo empleado.
     */
    public RegistroEmpleadoControlador(RegistroEmpleadoVista vista, String nextID) {
        this.ventana = vista;
        this.ventana.setLocationRelativeTo(null);
        this.empleado = new EmpleadoModelo();
        this.guardar = this.ventana.getBtnGuardar();
        this.ventana.getBtnGuardar().addActionListener(this);
        this.cancelar = this.ventana.getBtnCancelar();
        this.ventana.getBtnCancelar().addActionListener(this);
        this.id = nextID;
        this.ventana.setTxtID("B" + id);
    }

    /**
     * Metodo para convertir los datos del array a String.
     *
     * @return ArrayList de String.
     */
    public ArrayList<String> convertirString() {
        ArrayList<String> empleados = new ArrayList<>();
        for (int i = 0; i < LoginControlador.ListaEmpleados.size(); i++) {
            String cadena = null;
            cadena = LoginControlador.ListaEmpleados.get(i).toString();
            empleados.add(cadena);
        }
        return empleados;
    }

    /**
     * Metodo para generar un nuevo empleado y guardarlo en el archivo de texto.
     *
     * @param nombre contiene el nombre del empleado.
     * @param edad contiene la edad del empleado.
     * @param contrasenia contiene la contrasenia de empleado.
     * @param contrasenia2 contiene la confirmacion de la 1ra contrasenia
     * ingresada.
     */
    public void generarNuevoEmpleado(String nombre, int edad, String contrasenia, String contrasenia2) {
        Archivo archivo = new Archivo();
        String escribir = null;
        ArrayList<String> datos = new ArrayList<>();
        empleado.setID(id);
        empleado.setNombre(nombre);
        empleado.setEdad(edad);
        empleado.setContrasenia(contrasenia);
        LoginControlador.ListaEmpleados.add(new EmpleadoModelo(id,nombre,contrasenia,edad));
//        datos = convertirString();
        ArrayList<String> aux = new ArrayList<>();
        for (int i = 0; i < LoginControlador.ListaEmpleados.size(); i++) {
            aux.add(new Modelo.Convertidor().empleadoString(LoginControlador.ListaEmpleados.get(i)));
        }
        archivo.escribirArchivo("Empleados.txt", aux);
    }

    /**
     * Metodo para verificar que ningun campo este vacio.
     */
    public void verificarCampos() {
        if (this.ventana.getTxtNombre().getText().length() == 0) {
            throw new CampoVacio("Campo 'Nombre' vacio");
        }
        if (this.ventana.getTxtEdad().getText().length() == 0) {
            throw new CampoVacio("Campo 'Edad' vacio");
        }
        if (this.ventana.getTxtContraseña().getText().length() == 0) {
            throw new CampoVacio("Campo 'Contraseña' vacio");
        }
        if (this.ventana.getTxtContraseña2().getText().length() == 0) {
            throw new CampoVacio("Campo 'Confirmacion contraseña' vacio");
        }
    }

    /**
     * Metodo que verifica que accion se realizo en la pantalla.
     *
     * @param ae es la accion realizada por el usuario.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (this.guardar == ae.getSource()) {
            try {
                verificarCampos();
                nombre = this.ventana.getTxtNombre().getText();
                edad = Integer.parseInt(this.ventana.getTxtEdad().getText());
                contrasenia = this.ventana.getTxtContraseña().getText();
                contrasenia2 = this.ventana.getTxtContraseña2().getText();
                if (contrasenia.equals(contrasenia2)) {
                    generarNuevoEmpleado(nombre, edad, contrasenia, contrasenia2);
                } else {
                    throw new NoCoincidenciaContrasenia("Confirmacion de contraseña incorrecta");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "La edad tiene que ser un numero entero");
            } catch (NoCoincidenciaContrasenia e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage());
            } catch (CampoVacio e2) {
                JOptionPane.showMessageDialog(null, e2.getMessage());
            }
            this.ventana.setVisible(false);
        }
        if (this.cancelar == ae.getSource()) {
            ventana.setVisible(false);
        }
    }
}
