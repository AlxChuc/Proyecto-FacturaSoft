/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

import Modelo.Convertidor;
import Modelo.EmpleadoModelo;
import Modelo.NotaModelo;
import Modelo.ProductoModelo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author sam33
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {
        // TODO code application logic here
//        String numero = "1000";
//        char a1 = numero.charAt(0);
//        char a2 = numero.charAt(1);
//        char a3 = numero.charAt(2);
//        char a4 = numero.charAt(3);
//        String convertir = null;
//        convertir = ""+a1+a2+a3+a4;
//        int n = Integer.parseInt(convertir);
//        System.out.println(n);
//        String[] v = "ad/".split("/");
//        System.out.println(v.length);
//        Modelo.EmpleadoModelo eM = new Modelo.EmpleadoModelo("ID", "ales", "pass", 12);
//        ArrayList<Modelo.ProductoModelo> ar = new ArrayList<>();
//        Modelo.NotaModelo n = new Modelo.NotaModelo(ar, eM);
//
//        for (int i = 0; i < 3; i++) {
//            n.getProductos().add(new Modelo.ProductoModelo(String.valueOf(i), "zapato", 100, 1000));
//        }
//        eM.getNotas().add(n);
//
//        Modelo.NotaModelo n1 = new Modelo.NotaModelo(new ArrayList<Modelo.ProductoModelo>(), eM);
//
//        for (int i = 3; i < 6; i++) {
//            n1.getProductos().add(new Modelo.ProductoModelo(String.valueOf(i), "caja", 100, 1000));
//        }
//
//        eM.getNotas().add(n1);
////        n.getEmpleado().
//
//        String empleado = "";
//        String[] cad = eM.toString().split("/");
//        for (int i = 0; i < eM.toString().split("/").length; i++) {
//            System.out.print(cad[i] + "/");
//            empleado = empleado + cad[i] + "/";
//        }/*System.out.print(eM.toString2().split("/")[eM.toString2().split("/").length-1]);
//        System.out.println("\n");*/
//
//        for (int i = 0; i < eM.getNotas().size(); i++) {
//            System.out.print(eM.getNotas().get(i).getNumNota());
//            empleado = empleado + eM.getNotas().get(i).getNumNota() + ";";
//            System.out.print(";");
//            for (int j = 0; j < eM.getNotas().get(i).getProductos().size(); j++) {
////            System.out.println(eM.getNotas().get(0).getProductos());
//                empleado = empleado + eM.getNotas().get(i).getProductos().get(j) + "!";
//                System.out.print(eM.getNotas().get(i).getProductos().get(j) + "!");
//            }
//            System.out.print(";");
//            empleado = empleado + ";" + eM.getNotas().get(i).getFecha() + "_";
//            System.out.print(eM.getNotas().get(i).getFecha() + "_");
//        }
//
////        System.out.println("\n"+empleado);
//        System.out.println("\n" + new Convertidor().empleadoString(eM));
//
//        String[] aux = empleado.split("/");
//        EmpleadoModelo employ;
//        
//        String idEmpleado = aux[0];
//        String name = aux[1];
//        int edad = Integer.parseInt(aux[2]);
//        String pass = aux[3];
//        double saldo = Double.parseDouble(aux[4]);
//
//        for (int i = 0; i < aux.length; i++) {
//            System.out.println(aux[i]);
//        }
//        System.out.println("");
//        //aux.lenght-1 debería ser siempre = 5 porque solo debería tener 6 elementos "/"
//        //aquí están las notas
//        String[] aux2 = aux[aux.length - 1].split("_");
//        ArrayList<NotaModelo> notas  = new ArrayList<>();
//        for (int i = 0; i < aux2.length; i++) {
////            System.out.println(aux2[i]);
//            String[] aux3 = aux2[i].split(";");//Siempre van a ser 3 (id, productos,fecha)
//            System.out.println(aux3[0]+"<<<<<<<<");
//            int numNota = Integer.parseInt(aux3[0]);
//            System.out.println(aux3[1]+"<<<<<<<<");
//            //Faltan los productos, más adelante
//            System.out.println(aux3[2]+"<<<<<<<<");
//            String fecha = aux3[2];
//            ArrayList<ProductoModelo> arreglo = new ArrayList<>();
//            //Aquí se obtienen los los productos
//            String[] aux4 = aux3[1].split("!");
//            for (int j = 0; j < aux4.length; j++) {
//                System.out.println(aux4[j]);
//                String[] aux5 = aux4[j].split("@");
////                System.out.println(aux5.length+"<<<<<<<<<<<<<<");
//                String idProducto = aux5[0];
//                String desc = aux5[1];
//                int cantidad = Integer.parseInt(aux5[2]);
//                double prixInd = Double.parseDouble(aux5[3]);
//                for (int k = 0; k < aux5.length; k++) {
//                    System.out.println(aux5[k]);
//                }
//                arreglo.add(new ProductoModelo(idProducto,desc,cantidad,prixInd));
//            }
//            notas.add(new NotaModelo(arreglo,numNota,fecha));
////        for (int j = 0; j < aux3.length; j++) {
////            System.out.println(aux3[j]);
////            for (int k = 0; k < 10; k++) {
////                
////            }
////        }
//        }        employ = new EmpleadoModelo(idEmpleado,name,pass,edad,saldo,notas);
//        
//        System.out.println(empleado);
//        System.out.println(new Convertidor().empleadoString(new Convertidor().stringEmpleado(empleado)));
    }

}
