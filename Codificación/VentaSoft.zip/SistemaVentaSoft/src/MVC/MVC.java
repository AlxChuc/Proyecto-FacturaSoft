package MVC;

import Controlador.LoginControlador;
import Vista.LoginVista;

/**
 * Clase principal para poder inicializar el sistema.
 * @author Samantha Caamal.
 */
public class MVC {

    /**
     * @param args the command line arguments.
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LoginVista principal = new LoginVista();
        LoginControlador principalCtrl = new LoginControlador(principal);
        principal.setVisible(true);
    }
    
}
