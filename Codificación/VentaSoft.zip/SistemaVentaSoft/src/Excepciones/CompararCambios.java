package Excepciones;

/**
 * Clase que corresponde a comparar si se realizo algún cambio en
 * los datos solicitados.
 * @author Samantha Caamal.
 */
public class CompararCambios extends RuntimeException {
    /**
     * Clase que genera un mensaje que desea el programador.
     * @param mensaje contiene una cadena.
     */
    public CompararCambios(String mensaje) {
        super(mensaje);
    }
}
