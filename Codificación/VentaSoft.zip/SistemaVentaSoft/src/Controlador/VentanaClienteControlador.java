/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Vista.VentanaClienteVista;
import Modelo.ClienteModelo;
import Vista.HistorialClienteVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author sam33
 */
public class VentanaClienteControlador implements ActionListener {
        /**
     *VentanaEmpleadoVista
     */
    private VentanaClienteVista vCV;

    /**
     *EmpleadoModelo
     */
    private ClienteModelo cM;

    /**
     *Inicializa las variables, acomoda y ajusta la ventana
     * @param vCV tipo VentanaClienteVista
     * @param cliente tipo ClienteModelo
     */
    public VentanaClienteControlador(VentanaClienteVista vCV, ClienteModelo cliente) {
        this.vCV = vCV;
        this.cM = cliente;
        vCV.setLocationRelativeTo(null);

        vCV.getBtnSalir().addActionListener(this);
        vCV.getItemModificar().addActionListener(this);
        vCV.getMenuHistorial().addActionListener(this);

        vCV.setTitle("Bienvenido");
        vCV.getjLabel1().setText("Bienvenido " + cliente.getNombre().split(" ")[0]);
        vCV.getjLabel1().setHorizontalAlignment(vCV.getjLabel1().CENTER);
        vCV.setVisible(true);
    }

    /**
     * Selecciona que acción se realizo, en otras palabras, que fue lo que se
     * presiono, para invocar una accion.
     *
     * @param aE ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent aE) {
        if (vCV.getBtnSalir() == aE.getSource()) {
            /**/
            vCV.dispose();
        } else {
            if (vCV.getItemModificar() == aE.getSource()) {
                /*Activa la ventana de venta*/
                System.out.println("Ventana para modificar info de  cliente");
                //new ModificarClienteControlador(new ModificarClienteVista(), cM);
            } else {
                if (vCV.getMenuHistorial() == aE.getSource()) {
                    new HistorialClienteControlador(new HistorialClienteVista(),cM);
                }
            }

        }
    }

}

