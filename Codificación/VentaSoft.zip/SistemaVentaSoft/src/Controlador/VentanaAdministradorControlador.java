package Controlador;

import Vista.CambiarContraseniaAdmiVista;
import Vista.EditarEmpleadosVista;
import Vista.InformacionAdministradorVista;
import Vista.InformacionEmpleadoVista;
import Vista.RegistroEmpleadoVista;
import Vista.RegistroProductoVista;
import Vista.StockVista;
import Vista.VentanaAdministradorVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JMenuItem;

/**
 * Clase que controla las funciones de la ventana de administrador,
 * redirecciona las ventanas correspondiente seleccionado por el usuario.
 * @author Samantha Caamal.
 */
public class VentanaAdministradorControlador implements ActionListener {
    /**
     * Ventana del controlador.
     */
    public static VentanaAdministradorVista ventana;
    /**
     * Item del menu para modificar la informacion del administrador.
     */
    private JMenuItem modificarPerfil;
    /**
     * Item del menu para cambiar la contrasenia del administrador.
     */
    private JMenuItem cambiarContrasenia;
    /**
     * Item del menu para ingresar un nuevo empleado.
     */
    private JMenuItem nuevoEmpleado;
    /**
     * Item del menu para obtener la informacion de los empleados.
     */
    private JMenuItem infoEmpleados;
    /**
     * Item del menu para ingresar un nuevo producto.
     */
    private JMenuItem nuevoProducto;
    /**
     * Item del menu para acceder al Stock del sistema.
     */
    private JMenuItem stock;
    /**
     * Boton para salir de la ventana.
     */
    private JButton salir;
    /**
     * Contructor de la clase.
     * @param vista contiene la ventana a controlar.
     */
    public VentanaAdministradorControlador(VentanaAdministradorVista vista) {
        this.ventana = vista;
        this.ventana.setLocationRelativeTo(null);
        this.modificarPerfil = this.ventana.getmModificarPerfil();
        this.modificarPerfil.addActionListener(this);
        this.cambiarContrasenia = this.ventana.getmCambiarContrasenia();
        this.cambiarContrasenia.addActionListener(this);
        this.nuevoEmpleado = this.ventana.getmNuevoEmpleado();
        this.nuevoEmpleado.addActionListener(this);
        this.infoEmpleados = this.ventana.getmInformacionEmpleado();
        this.infoEmpleados.addActionListener(this);
        this.nuevoEmpleado = this.ventana.getmNuevoProducto();
        this.nuevoEmpleado.addActionListener(this);
        this.stock = this.ventana.getmStock();
        this.stock.addActionListener(this);
        this.ventana.setLbNombreUsuario(LoginControlador.Admi.getNombre());
        this.salir = this.ventana.getBtnSalir();
        this.salir.addActionListener(this);
        this.ventana.getmEditarInfoEmpleados().addActionListener(this);
    }
    /**
     * Metodo para obtener el ultimo ID utilizado para continuar de manera
     * secuencial.
     * @return ultimo ID que se utilizo.
     */
    public int getUltimoIDempleado(){
        int idEmpleado = 0;
        if (LoginControlador.ListaEmpleados.size() > 0) {
                System.out.println("Array con elementos");
                int tamanio = LoginControlador.ListaEmpleados.size() - 1;
                char a1 = LoginControlador.ListaEmpleados.get(tamanio).getID().charAt(1);
                char a2 = LoginControlador.ListaEmpleados.get(tamanio).getID().charAt(2);
                char a3 = LoginControlador.ListaEmpleados.get(tamanio).getID().charAt(3);
                char a4 = LoginControlador.ListaEmpleados.get(tamanio).getID().charAt(4);
                String convertir = "" + a1 + a2 + a3 + a4;
                idEmpleado = Integer.parseInt(convertir);
                System.out.println("Ultimo ID es: " + convertir);
            } else {
                System.out.println("Array vacio");
                idEmpleado = 1;
            }
        return idEmpleado;
    }
    /**
     * Metodo para obtener el ultimo ID utilizado para continuar de
     * manera secuencial.
     * @return ultimo ID que se utilizo.
     */
    public int ultimoIDproducto() {
        int idProducto = 0;
        if (LoginControlador.ListaProductos.size() > 0) {
            System.out.println("Array con elementos");
            int tamanio1 = LoginControlador.ListaProductos.size() - 1;
            char a1 = LoginControlador.ListaProductos.get(tamanio1).getIdProducto().charAt(1);
            char a2 = LoginControlador.ListaProductos.get(tamanio1).getIdProducto().charAt(2);
            char a3 = LoginControlador.ListaProductos.get(tamanio1).getIdProducto().charAt(3);
            char a4 = LoginControlador.ListaProductos.get(tamanio1).getIdProducto().charAt(4);
            String cadena = "" + a1 + a2 + a3 + a4;
            idProducto = Integer.parseInt(cadena);
            System.out.println("Ultimo ID es:" +  cadena);
        } else {
            System.out.println("Array vacio");
            idProducto = 1;
        }
        return idProducto;
    }
    /**
     * Metodo para generar el formato del ID.
     * @param id contiene un entero que representa el ID.
     * @return ID en forma de String con el formato correcto.
     */
    public static String  generarID(int id) {
        int dato = id;
        String num = "";
        int cont = 1;
        if ((dato >= 1000) || (dato < 1000)) {
            int can = cont + dato;
            num = "" + can;
        }
        if ((dato >= 100) || (dato < 100)) {
            int can = cont + dato;
            num = "0" + can;
        }
        if ((dato >= 9) || (dato < 100)) {
            int can = cont + dato;
            num = "00" + can;
        }
        if (dato < 9) {
            int can = cont + dato;
            num = "000" + can;
        }
        return num;
    }
    /**
     * Metodo que verifica que accion se realizo en la pantalla.
     * @param ae es la accion realizada por el usuario.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (this.modificarPerfil == ae.getSource()) {
            System.out.println("Perfil administrador...");
            InformacionAdministradorVista perfilVista = new InformacionAdministradorVista();
            InformacionAdministradorControlador perfilCtrl = new InformacionAdministradorControlador(perfilVista);
            perfilVista.setVisible(true);
        }
        if (this.cambiarContrasenia == ae.getSource()) {
            CambiarContraseniaAdmiVista cambiarVista = new CambiarContraseniaAdmiVista();
            CambiarContraseniaAdmiControlador cambiarCtrl = new CambiarContraseniaAdmiControlador(cambiarVista);
            cambiarVista.setVisible(true);
        }
        if (this.ventana.getmNuevoEmpleado() == ae.getSource()) {
            int ultimoIDe = getUltimoIDempleado();
            String nextID = generarID(ultimoIDe);
            RegistroEmpleadoVista nuevoVista = new RegistroEmpleadoVista();
            RegistroEmpleadoControlador nuevoCtrl = new RegistroEmpleadoControlador(nuevoVista, nextID);
            nuevoVista.setVisible(true);
        }
        if (this.infoEmpleados == ae.getSource()) {
            InformacionEmpleadoVista infoVista = new InformacionEmpleadoVista();
            InformacionEmpleadoControlador infoCtrl = new InformacionEmpleadoControlador(infoVista);
            infoVista.setVisible(true);
        }
        if (this.ventana.getmEditarInfoEmpleados() == ae.getSource()) {
            EditarEmpleadosVista EditarVista = new EditarEmpleadosVista();
            EditarEmpleadosControlador EditarCtrl = new EditarEmpleadosControlador(EditarVista);
            EditarVista.setVisible(true);
            
        }
        if (this.ventana.getmNuevoProducto() == ae.getSource()) {
            int ultimoIDp = ultimoIDproducto();
            String nextIDp = generarID(ultimoIDp);
            System.out.println(nextIDp);
            RegistroProductoVista productoVista = new RegistroProductoVista();
            RegistroProductoControlador productoCtrl = new RegistroProductoControlador(productoVista, nextIDp);
            productoVista.setVisible(true);
        }
        if (this.stock == ae.getSource()) {
            StockVista stockVista = new StockVista();
            StockControlador stockCtrl = new StockControlador(stockVista);
            stockVista.setVisible(true);
        }
        if (this.salir == ae.getSource()) {
            System.out.println("Boton salir");
            this.ventana.setVisible(false);
        }
    }
}
