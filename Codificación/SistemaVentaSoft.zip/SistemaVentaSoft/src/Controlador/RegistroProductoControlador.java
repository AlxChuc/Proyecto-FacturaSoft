package Controlador;

import Excepciones.CampoVacio;
import Modelo.Archivo;
import Modelo.ProductoModelo;
import Vista.RegistroProductoVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * Clase que controla la ventana que registra un nuevo producto.
 * @author Samantha Caamal.
 */
public class RegistroProductoControlador implements ActionListener{
    /**
     * Ventana del controlador.
     */
    private RegistroProductoVista ventana;
    /**
     * Boton para guardar el nuevo produto.
     */
    private JButton guardar;
    /**
     * Boton para salir de la ventana.
     */
    private JButton cancelar;
    /**
     * Cadena con el ID del producto.
     */
    private String id;
    /**
     * Cadena con la descripcion del producto.
     */
    private String descripcion;
    /**
     * Precio del producto.
     */
    private double precio;
    /**
     * Piezas existentes del producto.
     */
    private int piezas;
    /**
     * Instancia de la clase producto.
     */
    private ProductoModelo producto;
    /**
     * Contructor de la clase.
     * @param vista contiene la ventana a controlar.
     * @param nextID contiene el ID del siguiente producto.
     */
    public RegistroProductoControlador(RegistroProductoVista vista, String nextID) {
        this.ventana = vista;
        this.ventana.setLocationRelativeTo(null);
        this.guardar = this.ventana.getBtnGuardar();
        this.ventana.getBtnGuardar().addActionListener(this);
        this.cancelar = this.ventana.getBtnCancelar();
        this.ventana.getBtnCancelar().addActionListener(this);
        this.producto = new ProductoModelo();
        this.id = nextID;
        this.ventana.setTxtID("P" + id);
    }
    /**
     * Metodo para convertir a String los datos de los productos.
     * @return ArrayList de String.
     */
    public ArrayList<String> convertirString() {
        ArrayList<String> productos = new ArrayList<>();
        for (int i = 0; i < LoginControlador.ListaProductos.size(); i++) {
            String cadena = null;
            cadena = LoginControlador.ListaProductos.get(i).toString();
            productos.add(cadena);
        }
        return productos;
    }
    /**
     * Metodo que verifica que ningun campo este vacio.
     */
    public void verificarCampos() {
        if (this.ventana.getTxtDescripcion().getText().length() == 0) {
          throw new CampoVacio("Campo 'Descripcion' vacio");
        }
        if (this.ventana.getTxtPrecio().getText().length() == 0) {
            throw new CampoVacio("Campo 'Precio' vacio");
        }
    }
    /**
     * Metodo para generar el nuevo producto y guardarlo en el archivo de
     * texto.
     * @param id contiene la clave unica del producto.
     * @param descripcion contiene la descripcion del producto.
     * @param precio contiene el precio unitario del producto.
     * @param piezas contiene las piezas en existencia del producto.
     */
    public void generarNuevoProducto(String id, String descripcion, double precio, int piezas) {
        Archivo archivo = new Archivo();
        String escribir = null;
        ArrayList<String> datos = new ArrayList<>();
        producto.setIdProducto(id);
        producto.setDescripcion(descripcion);
        producto.setPrecioUnitario(precio);
        producto.setCantidad(piezas);
        LoginControlador.ListaProductos.add(producto);
        datos = convertirString();
        archivo.escribirArchivo("Productos.txt", datos);
    }
    /**
     * Metodo que verifica que accion se realizo en la pantalla.
     * @param ae es la accion realizada por el usuario.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (this.guardar == ae.getSource()) {
            try {
                verificarCampos();
                descripcion = this.ventana.getTxtDescripcion().getText();
                precio = Double.parseDouble(this.ventana.getTxtPrecio().getText());
                piezas = Integer.parseInt(this.ventana.getsPiezas().getValue().toString());
                generarNuevoProducto(id, descripcion, precio, piezas);
                this.ventana.setVisible(false);
            } catch (CampoVacio e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            } catch (NumberFormatException e1) { 
                JOptionPane.showMessageDialog(null, "La edad tiene que ser un numero entero");
            }
        }
        if (this.cancelar == ae.getSource()) {
            this.ventana.setVisible(false);
        }
    }
}
