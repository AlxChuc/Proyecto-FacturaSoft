/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author Alex
 */
public class Convertidor {
    
    /**
     * Convierte el empleado en un string
     * @param empleadoM EmpleadoModelo
     * @return String del empleado
     */
    public String empleadoString(EmpleadoModelo empleadoM){
        String empleado = "";
        String[] cad = empleadoM.toString().split("/");
        for (int i = 0; i < empleadoM.toString().split("/").length; i++) {
            empleado = empleado+cad[i]+"/";
        }
        for (int i = 0; i < empleadoM.getNotas().size(); i++) {
            empleado = empleado + empleadoM.getNotas().get(i).getNumNota() + ";";
            for (int j = 0; j < empleadoM.getNotas().get(i).getProductos().size(); j++) {
                empleado = empleado + empleadoM.getNotas().get(i).getProductos().get(j) + "!";
            }
            empleado = empleado + ";" + empleadoM.getNotas().get(i).getFecha() + "_";
        }
        return empleado;
    }
    
    /**
     *Convierte el string en un objeto de tipo EmpleadoModelo
     * @param empleado String
     * @return EmpleadoModelo
     */
    public EmpleadoModelo stringEmpleado(String empleado){
        
        String[] aux = empleado.split("/");
        EmpleadoModelo employ;
        
        String idEmpleado = aux[0];
        String name = aux[1];
        int edad = Integer.parseInt(aux[2]);
        String pass = aux[3];
        double saldo = Double.parseDouble(aux[4]);
        employ = new EmpleadoModelo(idEmpleado,name,pass,edad,saldo);
        
        String[] aux2 = aux[aux.length - 1].split("_");
        ArrayList<NotaModelo> notas  = new ArrayList<>();
        for (int i = 0; i < aux2.length; i++) {
            
            String[] aux3 = aux2[i].split(";");//Siempre van a ser 3 (id, productos,fecha)

            int numNota = Integer.parseInt(aux3[0]);
            //Faltan los productos, más adelante
            String fecha = aux3[2];
            ArrayList<ProductoModelo> arreglo = new ArrayList<>();
            //Aquí se obtienen los los productos
            String[] aux4 = aux3[1].split("!");
            for (int j = 0; j < aux4.length; j++) {
                String[] aux5 = aux4[j].split("@");
                String idProducto = aux5[0];
                String desc = aux5[1];
                int cantidad = Integer.parseInt(aux5[2]);
                double prixInd = Double.parseDouble(aux5[3]);
                
                arreglo.add(new ProductoModelo(idProducto,desc,cantidad,prixInd));
            }
            employ.getNotas().add(new NotaModelo(arreglo,numNota,fecha));
            notas.add(new NotaModelo(arreglo,numNota,fecha));
        }        
        return employ;
    }
}
