package Excepciones;

/**
 * Clase que corresponde a confirmacion de contrasenia incorrecta.
 * @author Samantha Caamal.
 */
public class NoCoincidenciaContrasenia extends RuntimeException {
    /**
     * Clase que genera un mensaje que desea el programador.
     * @param mensaje contiene una cadena.
     */
    public NoCoincidenciaContrasenia(String mensaje) {
        super(mensaje);
    }
}
