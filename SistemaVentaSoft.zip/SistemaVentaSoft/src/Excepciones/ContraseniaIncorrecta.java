package Excepciones;

/**
 * Clase que corresponde a contrasenia ingresada para
 * iniciar sesion incorrecta.
 * @author Samantha Caamal.
 */
public class ContraseniaIncorrecta extends RuntimeException {
    /**
     * Clase que genera un mensaje que desea el programador.
     * @param mensaje contiene una cadena.
     */
    public ContraseniaIncorrecta(String mensaje) {
        super(mensaje);
    }
}
