package Modelo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase para poder controlar las acciones/operaciones que se
 * realiza con los archivos de textos.
 * @author Samantha Caamal.
 */
public class Archivo {
    /**
     * Nombre del archivo de texto.
     */
    private String nombre;
    /**
     * Contructor vacio de la clase.
     */
    public Archivo() {
    }
    /**
     * Metodo para establecer el nombre del archivo de texto.
     * @param nombre contiene el nombre del archivo a utilizar.
     */
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    /**
     * Metodo para leer un archivo.
     * @param archivo archivo de texto del usuario.
     * @return datos ArrayList con los datos del archivo.
     */
    public ArrayList<String> leerArchivo(String archivo) {
        ArrayList<String> temporal = new ArrayList<>();
        
        try {

            FileReader fr = new FileReader(archivo);
            BufferedReader br = new BufferedReader(fr);
            String linea = "";

            while ((linea = br.readLine()) != null) {
                temporal.add(linea);
                
            }
            
            fr.close();
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado: " + archivo);
        } catch (IOException ex) {
            Logger.getLogger(Archivo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return temporal;
    }
    /**
     * Metodo para poder escribir en el archivo de texto.
     * @param archivo contiene el nombre del archivo a escribir.
     * @param datos contiene el ArrayList con los datos a escribir.
     */
    public void escribirArchivo(String archivo, ArrayList<String> datos) {
        try {
            FileWriter fr = new FileWriter(archivo);
            PrintWriter pw = new PrintWriter(fr);
            for (int i = 0; i < datos.size(); i++) {
//                System.out.println(datos.get(i));
                pw.println(datos.get(i));
            }
            pw.close();
        } catch (IOException e) {
            System.out.println("Error al imprimir...");
        }
    }
    /**
     * Metodo para obtener los datos del administrador.
     * @param datos es un ArrayList con los datos del archivo.
     * @return admi es un ArrayList que contiene los datos del administrador.
     */
    public AdministradorModelo convertirAdministrador(ArrayList<String> datos) {
        AdministradorModelo administrador = null;
        for (int i = 0; i < datos.size(); i++) {
            String[] cadena = datos.get(i).split("/");
            if (cadena.length == 3) {
                String id = cadena[0];
                String nombre = cadena[1];
                String contraseña = cadena[2];
               administrador = new AdministradorModelo(id, nombre, contraseña);
            }
        }
        
        
        return administrador;
    }
    /**
     * Metodo para obtener los datos de los clientes.
     * @param datos es un ArrayList de String con los datos del archivo.
     * @return ArrayList con objetos tipo Clientes.
     */
    public ArrayList<ClienteModelo> convertirClientes(ArrayList<String> datos){
        
        ArrayList<ClienteModelo> clientes = new ArrayList<>();
        
        for (int j = 0; j < datos.size(); j++) {
            String[] cadena = datos.get(j).split("/");
            if(cadena.length == 6){
                String id = cadena[0];
                String nombre = cadena[1];
                String contrasenia = cadena[2];
                String direccion = cadena[3];
                int telefono = Integer.parseInt(cadena[4]);
                int edad = Integer.parseInt(cadena[5]);
                
                ClienteModelo cliente = new ClienteModelo(id, nombre, contrasenia, direccion, telefono, edad);
                clientes.add(cliente);
            }else{
                if(cadena.length == 7){
                    clientes.add(new Convertidor().clienteString(datos.get(j)));
                }
            }
        }
        
        return clientes;
    }
    /**
     * Metodo para obtener los datos de los empleados.
     * @param datos contiene un ArrayList de String con los datos de los empleados.
     * @return ArrayList con objetos tipos Empleados.
     */
    public ArrayList<EmpleadoModelo> convetirEmpleadoModelo(ArrayList<String> datos){
        
        ArrayList<EmpleadoModelo> empleados = new ArrayList<>();
        
        for (int m = 0; m < datos.size(); m++) {
            String[] cadena = datos.get(m).split("/");
            if(cadena.length == 5){//Quiere decir que no tiene comisiones
                String id = cadena[0];
                String nombre = cadena[1];
                int edad = Integer.parseInt(cadena[2]);
                String contrasenia = cadena[3];
                double salario = Double.parseDouble(cadena[4]);
                
                empleados.add(new EmpleadoModelo(id, nombre, contrasenia, edad, salario));
            }else{
                if(cadena.length == 6){//Sí tiene comisiones
                    empleados.add(new Convertidor().stringEmpleado(datos.get(m)));
                }
                
            }
        }
        return empleados;
    }
    /**
     * Metodo para obtener los datos de los productos.
     * @param datos contiene un ArrayList de String con los datos del producto.
     * @return ArrayList con objetos tipos Productos.
     */
    public ArrayList<ProductoModelo> convertirProducto(ArrayList<String> datos){
        
        ArrayList<ProductoModelo> productos = new ArrayList<>();
        
        for (int n = 0; n < datos.size(); n++) {
            String[] cadena = datos.get(n).split("<");
            if(cadena.length == 4){
                String id = cadena[0];
                String descripcion = cadena[1];
                int cantidad = Integer.parseInt(cadena[2]);
                double precio = Double.parseDouble(cadena[3]);
                
                productos.add(new ProductoModelo(id, descripcion, cantidad, precio));
            }
        }
        
        return productos;
    }
}
