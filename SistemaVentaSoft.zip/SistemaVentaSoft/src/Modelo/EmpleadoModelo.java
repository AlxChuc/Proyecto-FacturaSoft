package Modelo;

import java.util.ArrayList;

/**
 * Clase que corresponde a un objeto empleado en el sistema,
 * contiene los atributos de un empleado.
 * @author Samantha Caamal.
 */
public class EmpleadoModelo extends Usuario {
    /**
     * Edad del empleado.
     */
    public int edad;
    /**
     * Salario del empleado.
     */
    public double salario;
    /**
     * Arreglo de todas la notas del empleado.
     */
    private ArrayList<NotaModelo> notas;
    /**
     * Constructor vacio.
     */
    public EmpleadoModelo(){
        this.salario = 1000;
    }
    /**
     * Constructor de la clase para instanciar.
     * @param ID contiene la clave unica del empleado.
     * @param nombre contiene el nombre del empleado.
     * @param contrasenia contiene la contrasenia de la cuenta del empleado.
     * @param edad contiene la edad del empleado.
     */
    public EmpleadoModelo(String ID, String nombre, String contrasenia, int edad) {
        super(ID, nombre, contrasenia);
        this.edad = edad;
        this.salario = 1000;
        this.notas = new ArrayList<>();
    }
    /**
     * Constructor para crear los empleados guardados en los archivos de texto.
     * @param ID contiene la clave unica del empleado.
     * @param nombre contiene el nombre completo del empleado.
     * @param contrasenia contiene la contrasenia de la cuenta del empleado.
     * @param edad contiene la edad del empleado.
     * @param salario contiene el salario del empleado.
     */
    public EmpleadoModelo(String ID, String nombre, String contrasenia, int edad, double salario) {
        super(ID, nombre, contrasenia);
        this.ID = ID;
        this.nombre = nombre;
        this.contrasenia = contrasenia;
        this.edad = edad;
        this.salario = salario;
        this.notas = new ArrayList<>();
    }
    
    //Metodos get y set
    /**
     * Metodo para obtener la edad del empleado.
     * @return edad del empleado.
     */
    public int getEdad() {
        return edad;
    }
    /**
     * Metodo para establecer la edad del empleado.
     * @param edad contiene un numero entero con la edad del empleado.
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }
    /**
     * Metodo para obtener el salario del empleado.
     * @return salario del empleado.
     */
    public double getSalario() {
        return salario;
    }
    /**
     * Metodo para establecer el salario del empleado.
     * @param salario contiene un double con el salario del empleado.
     */
    public void setSalario(double salario) {
        this.salario = salario;
    }
    /**
     * Devuelve un arreglo con las notas(lo que ha vendido) del empleado
     * @return ArrayList de las notas del Empleado
     */
    public ArrayList<NotaModelo> getNotas() {
        return notas;
    }
    //Metodos abstractos
    /**
     * Metodo heredado para establecer la contrasenia del empleado.
     * @param contrasenia contiene una cadena ingresada por el empleado.
     */
    @Override
    public void setContrasenia(String contrasenia) {
        super.setContrasenia(contrasenia);
    }
    /**
     * Metodo heredado para obtener la contrasenia del empleado.
     * @return contrasenia contiene un string.
     */
    @Override
    public String getContrasenia() {
        return super.getContrasenia();
    }
    /**
     * Metodo heredado para establecer el nombre del empleado.
     * @param nombre contiene un string.
     */
    @Override
    public void setNombre(String nombre) {
        super.setNombre(nombre);
    }
    /**
     * Metodo heredado para obtener el nombre del empleado.
     * @return nombre del empleado.
     */
    @Override
    public String getNombre() {
        return super.getNombre();
    }
    /**
     * Metodo heredado para establecer el ID del empleado.
     * @param ID contiene un string.
     */
    @Override
    public void setID(String ID) {
        super.setID(ID);
    }
    /**
     * Metodo heredado para obtener el ID del empleado.
     * @return ID con la clave del empleado.
     */
    @Override
    public String getID() {
        return "B" + super.getID();
    }
    /**
     * Metodo para poder escribir la informacion del empleado.
     * @return cadena con los datos del empleado.
     */
    @Override
    public String toString() {
        return this.ID + "/" + this.nombre + "/" + this.edad+ "/"+ this.contrasenia + "/" + this.salario;
    }
}
