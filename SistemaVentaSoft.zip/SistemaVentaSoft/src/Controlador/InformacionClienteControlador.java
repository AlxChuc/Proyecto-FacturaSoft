/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Excepciones.CompararCambios;
import Excepciones.ContraseniaIncorrecta;
import Modelo.Archivo;
import Controlador.LoginControlador;
import Vista.InformacionClienteVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * Clase para generar el historial del cliente.
 * @author ElenaMariel
 */
public class InformacionClienteControlador /*implements ActionListener*/{
/*    public InformacionClienteVista ventana;
    public String nombre;
    public String contrasenia;
    public JButton guardar;
    public JButton cancelar;
    private Archivo escribir = new Archivo();
    private ArrayList<String> dato = new ArrayList<>();
    
    public InformacionClienteControlador(InformacionClienteVista vista){
        this.ventana = vista;
        this.ventana.setLocationRelativeTo(null);
        this.ventana.setTxtID(LoginControlador.ListaClientes.getID());
        this.ventana.setTxtNombre(LoginControlador.ListaClientes.nombre);
        this.guardar = this.ventana.getBtnGuardar();
        this.ventana.getBtnGuardar().addActionListener(this);
        this.cancelar = this.ventana.getBtnSalir();
        this.ventana.getBtnSalir().addActionListener(this);
    }
    
    public void guardarCambios(String nombre, String contrasenia){
        if(nombre != LoginControlador.ListaClientes.getNombre()){
            if(contrasenia.equals(LoginControlador.ListaClientes.getContrasenia())){
                LoginControlador.ListaClientes.setNombre(nombre);
                for (int i = 0; i < 1; i++) {
                    dato.add(LoginControlador.ListaClientes.toString());
                }
                System.out.println(dato);
                escribir.escribirArchivo("ListaClientes.txt", dato);
                JOptionPane.showMessageDialog(null, "Cambio guardado con éxito");
                VentanaListaClienteControlador.ventana.setLbNombreUsuario(LoginControlador.ListaClientes.getNombre());
                this.ventana.setVisible(false);
            }else{
                throw new ContraseniaIncorrecta("No se puede guardar los cambios, contraseña incorrecta.");
            }
        }else{
            throw new CompararCambios("No se realizo ningun cambio a la informacion del usuario.");
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(this.guardar == ae.getSource()){
            try{
                nombre = this.ventana.getTxtNombre().getText();
                contrasenia = this.ventana.getTxtContrasenia1().getText();
                guardarCambios(nombre, contrasenia);
            }catch(ContraseniaIncorrecta e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }catch(CompararCambios e1){
                JOptionPane.showMessageDialog(null, e1.getMessage());
            }
        }
        if(this.cancelar == ae.getSource()){
            this.ventana.setVisible(false);
        }
    }*/
}