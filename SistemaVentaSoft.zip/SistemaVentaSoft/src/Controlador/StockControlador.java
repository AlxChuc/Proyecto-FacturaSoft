package Controlador;

import Excepciones.CampoVacio;
import Modelo.Archivo;
import Vista.StockVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Clase que controla la ventana de Stock.
 * @author Samantha Caamal.
 */
public class StockControlador implements ActionListener, MouseListener {
    /**
     * Variable para instanciar la vista de Stock.
     */
    private StockVista ventana;
    /**
     * Variable para controlar las funciones de una tabla.
     */
    private DefaultTableModel model;
    /**
     * Tabla que almacena los datos de los productos.
     */
    public JTable tabla;
    /**
     * Boton para editar la informacion del producto.
     */
    private JButton editar;
    /**
     * Boton para elimiar un producto.
     */
    private JButton eliminar;
    /**
     * Boton para guardar los cambios realizados a los datos del producto.
     */
    private JButton guardar;
    /**
     * Boton para salir de la ventana.
     */
    private JButton salir;
    /**
     * Variable para almacenar el id del producto.
     */
    private String id;
    /**
     * Variable para almacenar la posicion del producto a modificar.
     */
    private int indicador;
    /**
     * Contructor de la clase.
     * @param vista contiene la ventana a controlar.
     */
    StockControlador(StockVista vista) {
        this.ventana = vista;
        this.ventana.setLocationRelativeTo(null);
        this.tabla = this.ventana.getTablaProductos();
        this.editar = this.ventana.getBtnEditar();
        this.ventana.getBtnEditar().addActionListener(this);
        this.eliminar = this.ventana.getBtnEliminar();
        this.ventana.getBtnEliminar().addActionListener(this);
        this.guardar = this.ventana.getBtnCambios();
        this.ventana.getBtnCambios().addActionListener(this);
        this.salir = this.ventana.getBtnSalir();
        this.ventana.getBtnSalir().addActionListener(this);
        tabla.addMouseListener(this);
        vista.setTitle("Stock");
        mostrarDatosTabla();
    }
    /**
     * Metodo para mostrar los datos de todos los productos en la tabla
     * de la ventana.
     */
    public void mostrarDatosTabla() {
        String[] titulos = {"ID", "Descripcion", "Piezas disponibles", "Precio unitario"};
        model = new DefaultTableModel(null, titulos) {
            /**
             * Metodo para volver ineditable las celdas de la tabla.
             * @param fila contiene la posicion de la fila.
             * @param columna contiene la posicion de la columna.
             * @return false para que no sea editable.
             */
            @Override
            public boolean isCellEditable (int fila, int columna) {
                return false;
            }
        };
        String[] datos = new String[4];
        for (int i = 0; i < LoginControlador.ListaProductos.size(); i++) {
            datos[0] = LoginControlador.ListaProductos.get(i).getIdProducto();
            datos[1] = LoginControlador.ListaProductos.get(i).getDescripcion();
            datos[2] = Integer.toString(LoginControlador.ListaProductos.get(i).getCantidad());
            datos[3] = Double.toString(LoginControlador.ListaProductos.get(i).getPrecioUnitario());
            model.addRow(datos);
            model.isCellEditable(i, 0);
            model.isCellEditable(i, 1);
            model.isCellEditable(i, 2);
            model.isCellEditable(i, 3);
            this.tabla.setModel(model);
            this.ventana.setTablaProductos(tabla);
        }
    }
    /**
     * Metodo para colocar los datos en las celdas para poder editarlos.
     * @param id del produccto a editar.
     * @return la posicion en el ArrayList del producto.
     */
    public int colocarDatos(String id) {
        int indicador = 0;
        for (int i = 0; i < LoginControlador.ListaProductos.size(); i++) {
            if (id.equals(LoginControlador.ListaProductos.get(i).getIdProducto())) {
                this.ventana.setTxtID(LoginControlador.ListaProductos.get(i).getIdProducto());
                this.ventana.setTxtDescripcion(LoginControlador.ListaProductos.get(i).getDescripcion());
                this.ventana.setTxtPrecio(Double.toString(LoginControlador.ListaProductos.get(i).getPrecioUnitario()));
                indicador = i;
            }
        }
        return indicador;
    }
    /**
     * Metodo para convertir en un ArrayList de String los datos de todos los
     * productos.
     * @return ArrayList de String con los datos de los productos.
     */
    public ArrayList<String> convertirString(){
        ArrayList<String> productos = new ArrayList<>();
        for (int i = 0; i < LoginControlador.ListaProductos.size(); i++) {
            String cadena = null;
            cadena = LoginControlador.ListaProductos.get(i).toString();
            productos.add(cadena);
        }
        return productos;
    }
    /**
     * Metodo para realizar los cambios solicitados por el usuario
     * en la informacion de producto seleccionado.
     * @param id contiene la posicion del producto en el arreglo.
     * @param descripcion contiene la descripcion del producto.
     * @param precio contiene el precio del produ to.
     * @param unidades contiene las unidades añadidas a las cantidad existente.
     */
    public void realizarCambios(int id, String descripcion, double precio, int unidades) {
        Archivo archivo = new Archivo();
        ArrayList<String> datos = new ArrayList<>();
        LoginControlador.ListaProductos.get(id).setDescripcion(descripcion);
        LoginControlador.ListaProductos.get(id).setPrecioUnitario(precio);
        int masPiezas = unidades + LoginControlador.ListaProductos.get(id).getCantidad();
        LoginControlador.ListaProductos.get(id).setCantidad(masPiezas);
        datos = convertirString();
        archivo.escribirArchivo("Productos.txt", datos);
    }
    /**
     * Metodo que obtiene la posicion en el arreglo del elemento solicitado.
     * @param id contiene el ID del producto.
     * @return indicador con la posicion del producto.
     */
    public int obtenerPosicion(String id) {
        int indi = 0;
        for (int j = 0; j < LoginControlador.ListaProductos.size(); j++) {
            if (id.equals(LoginControlador.ListaProductos.get(j).getIdProducto())) {
                indi = j;
            }
        }
        return indi;
    }
    /**
     * Metodo que verifica que accion se realizo en la pantalla.
     * @param ae es la accion realizada por el usuario.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        //Si el boton Editar fue pulsado
        if (this.editar == ae.getSource()) {
            try {
                if (this.ventana.getTxtIDEliminar().getText().length() != 0) {
                    id = this.ventana.getTxtIDEliminar().getText();
                    indicador = colocarDatos(id);
                } else {
                    throw new CampoVacio("Favor de seleccionar un articulo de la tabla.");
                }
            } catch (CampoVacio e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
        //Si el boton Guardar cambios fue pulsado.
        if (this.guardar == ae.getSource()) {
            try {
                if (this.ventana.getTxtID().getText().length() != 0) {
                    String descripcion = this.ventana.getTxtDescripcion().getText();
                    double precio = Double.parseDouble(this.ventana.getTxtPrecio().getText());
                    int unidades = Integer.parseInt(this.ventana.getsAgregarUnidades().getValue().toString());
                    realizarCambios(indicador, descripcion, precio, unidades);
                    mostrarDatosTabla();
                } else {
                    throw new CampoVacio("Favor de seleccionar un articulo de la tabla.");
                }
            } catch (CampoVacio e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            } catch (NumberFormatException e) { 
                JOptionPane.showMessageDialog(null, "La edad tiene que ser un numero entero");
            }
        }
        //Si el boton Eliminar elemento fue pulsado.
        if (this.eliminar == ae.getSource()) {
            try {
                if (this.ventana.getTxtIDEliminar().getText().length() != 0) {
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Realmente desea eliminar el producto: " + this.ventana.getTxtIDEliminar().getText()+ "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (opcion == 0) {
                        id = this.ventana.getTxtIDEliminar().getText();
                        int posicion = obtenerPosicion(id);
                        LoginControlador.ListaProductos.remove(posicion);
                        Archivo archivo = new Archivo();
                        ArrayList<String> datos = new ArrayList<>();
                        datos = convertirString();
                        archivo.escribirArchivo("Productos.txt", datos);
                        mostrarDatosTabla();
                    }
                } else {
                    throw new CampoVacio("Favor de seleccionar un articulo de la tabla.");
                }
            } catch (CampoVacio e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
        //Si el boton Salir fue pulsado.
        if (this.salir == ae.getSource()) {
            this.ventana.setVisible(false);
        }
    }
    /**
     * Metodo abstracto paara verificar a que fila de la tabla le realizaron 2
     * click y colocar el ID en el recuadro correspondiente.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseClicked(MouseEvent me) {
        if(tabla == me.getSource() && me.getClickCount() == 2){
            int filaPulsada = tabla.getSelectedRow();
            if( filaPulsada >= 0){
                String id = (String)this.tabla.getValueAt(filaPulsada, 0);
                this.ventana.setTxtIDEliminar(id);
            }
        }
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mousePressed(MouseEvent me) {
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseReleased(MouseEvent me) {
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseEntered(MouseEvent me) {
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseExited(MouseEvent me) {
    }
}
