/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Excepciones.CompararCambios;
import Excepciones.ContraseniaIncorrecta;
import Excepciones.NoCoincidenciaContrasenia;
import Modelo.Archivo;
import Modelo.ClienteModelo;
import Vista.CambiarContraseniaVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * Clase que cambia la contrasenia del cliente.
 * @author ElenaMariel
 */
public class CambiarContraseniaClienteControlador implements ActionListener {
    /**
     * Ventana del controlador.
     */
    private CambiarContraseniaVista ventana;
    /**
     * Boton para guardar cambios.
     */
    private JButton guardar;
    /**
     * Boton para salir de la ventana.
     */
    private JButton salir;
    /**
     * Cadena que contiene la contrasenia actual del usuario.
     */
    private String antiguaContrasenia;
    /**
     * Cadena que contiene la nueva contrasenia del usuario.
     */
    private String nuevaContrasenia;
    /**
     * Cadena que contiene la confirmacion de la nueva contrasenia.
     */
    private String nuevaContrasenia2;
    /**
     * Archivo para guardar la informacion modificada.
     */
    private Archivo escribir = new Archivo();
    /**
     * ArrayList<String> para guardar temporalmente los datos.
     */
    private ArrayList<String> dato = new ArrayList<>();
    /**
     * Cliente que inicio sesion.
     */
    private ClienteModelo cliente;
    /**
     * Constructor de la clase.
     * @param vista es la ventana a controlar.
     * @param cliente es el cliente que inicio sesion.
     */
    public CambiarContraseniaClienteControlador(CambiarContraseniaVista vista, ClienteModelo cliente) {
        this.ventana = vista;
        this.cliente = cliente;
        this.ventana.setLocationRelativeTo(null);
        this.guardar = this.ventana.getBtnGuardar();
        this.ventana.getBtnGuardar().addActionListener(this);
        this.salir = this.ventana.getBtnCancelar();
        this.ventana.getBtnCancelar().addActionListener(this);
    }
    /**
     * Metodo para poder verificar que el usuario esta ingresando
     * correctamente todos los dato solicitados.
     * @param antigua contiene la actual contrasenia.
     * @param nueva contiene la nueva contrasenia.
     * @param nueva2 confirma la nueva contrasenia.
     */
    public void verificar(String antigua, String nueva, String nueva2) {
        if (antigua.equals(cliente.getContrasenia())) {
            if (nueva.equals(cliente.getContrasenia())) {
                throw new CompararCambios("No se ha realizado cambios en la contraseña.");
            } else {
                if (nueva.equals(nueva2)) {
                    cliente.setContrasenia(nueva);
                    ArrayList<String> aux = new ArrayList<>();
                    for (int i = 0; i < LoginControlador.ListaClientes.size(); i++) {
                        aux.add(new Modelo.Convertidor().stringCliente(LoginControlador.ListaClientes.get(i)));
                    }

                    escribir.escribirArchivo("Clientes.txt", aux);
                    JOptionPane.showMessageDialog(null, "Cambio guardado con éxito");
                    this.ventana.setVisible(false);
                } else {
                    throw new NoCoincidenciaContrasenia("Confirmacion incorrecta.");
                }
            }
        } else {
            throw new ContraseniaIncorrecta("Contrasenia incorrecta.");
        }
    }
    /**
     * Metodo que verifica que boton fue pusheado.
     * @param ae contiene la accion que solicita el usuario.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (this.guardar == ae.getSource()) {
            antiguaContrasenia = this.ventana.getTxtContraseniaAntigua().getText();
            nuevaContrasenia = this.ventana.getTxtContrasenia1().getText();
            nuevaContrasenia2 = this.ventana.getTxtContrasenia2().getText();
            try {
                verificar(antiguaContrasenia, nuevaContrasenia, nuevaContrasenia2);
            } catch (CompararCambios e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            } catch (NoCoincidenciaContrasenia e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage());
            } catch (ContraseniaIncorrecta e2) {
                JOptionPane.showMessageDialog(null, e2.getMessage());
            }
        }

        if (this.salir == ae.getSource()) {
            this.ventana.setVisible(false);
        }
    }

}
