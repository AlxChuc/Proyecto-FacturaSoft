/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.EmpleadoModelo;
import Vista.CambiarContraseniaVista;
import Vista.ComisionesEmpleadoVista;
import Vista.VentaVista;
import Vista.VentanaEmpleadoVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Clase que muestra la venta del empleado, con las
 * opciones que este puede realizar.
 * @author sam33
 */
public class VentanaEmpleadoControlador implements ActionListener {
    /**
     *VentanaEmpleadoVista
     */
    private VentanaEmpleadoVista vEV;

    /**
     *EmpleadoModelo
     */
    private EmpleadoModelo eM;

    /**
     *Inicializa las variables, acomoda y ajusta la ventana
     * @param vEV tipo VentanaEmpleadoVista
     * @param empleado tipo EmpleadoModelo
     */
    public VentanaEmpleadoControlador(VentanaEmpleadoVista vEV, EmpleadoModelo empleado) {
        LoginControlador.ventana.setVisible(false);
        this.vEV = vEV;
        this.eM = empleado;
        vEV.setLocationRelativeTo(null);

        vEV.getBtnSalir().addActionListener(this);
        vEV.getItemVenta().addActionListener(this);
        vEV.getItemComision().addActionListener(this);
        vEV.getItemPass().addActionListener(this);
        
        vEV.setTitle("Bienvenido");
        vEV.getjLabel1().setText("Bienvenido " + empleado.getNombre().split(" ")[0]);
        vEV.getjLabel1().setHorizontalAlignment(vEV.getjLabel1().CENTER);
        vEV.setVisible(true);
    }

    /**
     * Selecciona que acción se realizo, en otras palabras, que fue lo que se
     * presiono, para invocar una accion.
     *
     * @param ae ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (vEV.getBtnSalir() == ae.getSource()) {
            /**/
            vEV.dispose();
            LoginControlador.ventana.setVisible(true);
//            new Vista.LoginVista().setVisible(true);
        } else {
            if (vEV.getItemVenta() == ae.getSource()) {
                /*Activa la ventana de venta*/
                new VentaControlador(new VentaVista(), eM);
            } else {
                if (vEV.getItemComision() == ae.getSource()) {
                    new ComisionesEmpleadoControlador(new ComisionesEmpleadoVista(),eM);
                }else{
//                    System.out.println("fdd");
                    if(vEV.getItemPass() == ae.getSource()){
//                        System.out.println("sdegarf");
                        CambiarContraseniaVista cc = new CambiarContraseniaVista();
                        new CambiarPassEmpleado(cc);
                        cc.setVisible(true);
                    }
                }
            }

        }
    }
}
