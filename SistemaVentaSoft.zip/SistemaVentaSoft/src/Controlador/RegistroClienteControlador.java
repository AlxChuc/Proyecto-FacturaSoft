/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Excepciones.CampoVacio;
import Excepciones.NoCoincidenciaContrasenia;
import Modelo.Archivo;
import Modelo.ClienteModelo;
import Vista.RegistroClienteVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * Clase que se encarga de el registro de los clientes.
 * @author sam33
 */
public class RegistroClienteControlador implements ActionListener {

    /**
     * Ventana del controlador.
     */
    private RegistroClienteVista ventana;
    /**
     * Boton para guardar el nuevo cliente.
     */
    private JButton guardar;
    /**
     * Boton para cancelar la operacion.
     */
    private JButton cancelar;
    /**
     * Cadena con el nombre del cliente.
     */
    private String nombre;
    /**
     * Cadena con el ID del cliente.
     */
    private String id;
    /**
     * Telefomo del cliente.
     */
    private String direccion;
    /**
     * Cadena con el ID del cliente.
     */
    private int telefono;
    /**
     * Edad del cliente.
     */
    private int edad;
    /**
     * Contrasenia de la cuenta del cliente.
     */
    private String contrasenia;
    /**
     * Confirmacion de la contrasenia ingresada.
     */
    private String contrasenia2;

    /**
     * Contructor de la clase.
     *
     * @param vista contiene la ventana a controlar.
     * @param nextID contiene el ID del nuevo cliente.
     */
    public RegistroClienteControlador(RegistroClienteVista vista, String nextID) {
        this.ventana = vista;
        this.ventana.setLocationRelativeTo(null);
        this.guardar = this.ventana.getBtnRegistrar();
        this.ventana.getBtnRegistrar().addActionListener(this);
        this.cancelar = this.ventana.getBtnSalir();
        this.ventana.getBtnSalir().addActionListener(this);
        this.id = nextID;
        this.ventana.setTxtID("C" + id);
    }

    /**
     * Metodo para convertir los datos del array a String.
     *
     * @return ArrayList de String.
     */
    public ArrayList<String> convertirString() {
        ArrayList<String> clientes = new ArrayList<>();
        for (int i = 0; i < LoginControlador.ListaClientes.size(); i++) {
            String cadena = null;
            cadena = LoginControlador.ListaClientes.get(i).toString();
            System.out.println(cadena);
            clientes.add(cadena);
        }
        return clientes;
    }

    /**
     * Metodo para generar un nuevo cliente y guardarlo en el archivo de texto.
     *
     * @param nombre contiene el nombre del cliente.
     * @param direccion la direccion del cliente
     * @param telefono contiene la edad del cliente.
     * @param edad la edad del cliente
     * @param contrasenia contiene la contrasenia de cliente.
     */
    public void generarNuevoCliente(String nombre, String direccion, int telefono, int edad, String contrasenia) {
        Archivo archivo = new Archivo();
        String escribir = null;
//        ArrayList<String> datos = new ArrayList<>();
//        LoginControlador.ListaClientes.add(new ClienteModelo(id, nombre, contrasenia, direccion, telefono, edad));
//        datos = convertirString();
        ArrayList<String> aux = new ArrayList<>();
        for (int i = 0; i < LoginControlador.ListaClientes.size(); i++) {
            aux.add(new Modelo.Convertidor().empleadoString(LoginControlador.ListaEmpleados.get(i)));
        }
        archivo.escribirArchivo("Clientes.txt", aux);
    }

    /**
     * Metodo para verificar que ningun campo este vacio.
     */
    public void verificarCampos() {
        if (this.ventana.getTxtNombre().getText().length() == 0) {
            throw new CampoVacio("Campo 'Nombre' vacio");
        }
        if (this.ventana.getTxtDireccion().getText().length() == 0) {
            throw new CampoVacio("Campo 'Direccion' vacio");
        }
        if (this.ventana.getTxtTelefono().getText().length() == 0) {
            throw new CampoVacio("Campo 'Telefono' vacio");
        }
        if (this.ventana.getTxtContrasenia1().getText().length() == 0) {
            throw new CampoVacio("Campo 'Contraseña' vacio");
        }
        if (this.ventana.getTxtEdad().getText().length() == 0) {
            throw new CampoVacio("Campo 'Edad' vacio");
        }
        if (this.ventana.getTxtContrasenia2().getText().length() == 0) {
            throw new CampoVacio("Campo 'Confirmacion contraseña' vacio");
        }
    }

    /**
     * Metodo que verifica que accion se realizo en la pantalla.
     *
     * @param ae es la accion realizada por el usuario.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (this.guardar == ae.getSource()) {
            try {
                verificarCampos();
                nombre = this.ventana.getTxtNombre().getText();
                direccion = this.ventana.getTxtDireccion().getText();
                telefono = Integer.parseInt(this.ventana.getTxtTelefono().getText());
                edad = Integer.parseInt(this.ventana.getTxtEdad().getText());
                contrasenia = this.ventana.getTxtContrasenia1().getText();
                contrasenia2 = this.ventana.getTxtContrasenia2().getText();
                if (contrasenia.equals(contrasenia2)) {
                    System.out.println("contrasenias iguales");
                    generarNuevoCliente(nombre, direccion, telefono, edad, contrasenia);
                    JOptionPane.showMessageDialog(null, "Cliente generado con exito");
                } else {
                    throw new NoCoincidenciaContrasenia("Confirmacion de contraseña incorrecta");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "La edad tiene que ser un numero entero");
            } catch (NoCoincidenciaContrasenia e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage());
            } catch (CampoVacio e2) {
                JOptionPane.showMessageDialog(null, e2.getMessage());
            }
            this.ventana.setVisible(false);
        }
        if (this.cancelar == ae.getSource()) {
            ventana.setVisible(false);
        }
    }
}
