/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

import Modelo.ClienteModelo;
import Modelo.Convertidor;
import Modelo.NotaModelo;
import Modelo.ProductoModelo;
import java.util.ArrayList;

/**
 *
 * @author Alex
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<ProductoModelo> array = new ArrayList<>();
        ProductoModelo p = new ProductoModelo("00","zap",30,100);
        ProductoModelo p1 = new ProductoModelo("12","sss",30,100);
        ProductoModelo p2 = new ProductoModelo("3","wq",30,100);
        array.add(p);
        array.add(p1);
        array.add(p2);
        NotaModelo n = new NotaModelo(array,0,"martes");
        NotaModelo n2 = new NotaModelo(array,1,"mier");
        
        ClienteModelo cM = new ClienteModelo("00","name","123","call",999,12);
        cM.getNotas().add(n);
        cM.getNotas().add(n2);
        
        System.out.println(new Convertidor().stringCliente(cM));
        System.out.println(cM);
        
        System.out.println(new Convertidor().clienteString(new Convertidor().stringCliente(cM)));
        System.out.println(new Convertidor().clienteString(new Convertidor().stringCliente(cM)).getNotas());
    }
    
}
