package MVC;

import Controlador.LoginControlador;
import Vista.LoginVista;
import Vista.LookFeel;

/**
 * Clase principal para poder inicializar el sistema.
 * @author Samantha Caamal.
 */
public class MVC {

    /**
     * @param args the command line arguments.
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new LookFeel().setLookAndFeel();
        
        LoginVista principal = new LoginVista();
        LoginControlador principalCtrl = new LoginControlador(principal);
        principal.setVisible(true);
    }
    
}
