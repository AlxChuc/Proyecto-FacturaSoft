package Excepciones;

/**
 * Clase que corresponde que un campo de texto se encuentra sin parametro
 * para poder leer.
 * @author Samantha Caamal.
 */
public class CampoVacio extends RuntimeException {
    /**
     * Clase que genera un mensaje que desea el programador.
     * @param mensaje contiene una cadena.
     */
    public CampoVacio(String mensaje) {
        super(mensaje);
    }
}
