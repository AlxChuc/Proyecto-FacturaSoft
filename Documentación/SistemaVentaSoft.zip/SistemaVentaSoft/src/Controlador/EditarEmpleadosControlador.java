package Controlador;


import Excepciones.CampoVacio;
import Modelo.Archivo;
import Vista.EditarEmpleadosVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 * Clase que gestiona los cambios de informacion de los empleados, asi
 * también se encarga de eliminar empleados.
 * @author Samantha Caamal
 */
public class EditarEmpleadosControlador implements ActionListener, MouseListener {
    /**
     * Ventana del controlador.
     */
    private EditarEmpleadosVista ventana;
        /**
     * Variable para controlar las funciones de una tabla.
     */
    private DefaultTableModel model;
    /**
     * Tabla que almacena los datos de los empleados.
     */
    public JTable tabla;
    /**
     * Variable para almacenar el id del empleado.
     */
    private String id;
    /**
     * Variable para almacenar la posicion del empleado a modificar.
     */
    private int indicador;
    /**
     * Contructor de la clase.
     * @param vista contiene la ventana a controlar.
     */
    public EditarEmpleadosControlador(EditarEmpleadosVista vista){
        this.ventana = vista;
        this.ventana.setLocationRelativeTo(null);
        this.ventana.getBtnEditar().addActionListener(this);
        this.ventana.getBtnEliminar().addActionListener(this);
        this.ventana.getBtnGuardar().addActionListener(this);
        this.ventana.getBtnSalir().addActionListener(this);
        this.tabla = this.ventana.getTablaEmpleados();
        tabla.addMouseListener(this);
        mostrarDatosTabla();
    }
    /**
     * Metodo para poder mostrar la informacion de los empleados en la tabla
     * de la ventana.
     */
    public void mostrarDatosTabla() {
        String[] titulos = {"ID", "Nombre del empleado", "Edad", "Contrasenia"};
        model = new DefaultTableModel(null, titulos) {
            /**
             * Metodo para volver ineditable las celdas de la tabla.
             * @param fila contiene la posicion de la fila.
             * @param columna contiene la posicion de la columna.
             * @return false para que no sea editable.
             */
            @Override
            public boolean isCellEditable (int fila, int columna) {
                return false;
            }
        };
        String[] datos = new String[4];
        for (int i = 0; i < LoginControlador.ListaEmpleados.size(); i++) {
            datos[0] = LoginControlador.ListaEmpleados.get(i).getID();
            datos[1] = LoginControlador.ListaEmpleados.get(i).getNombre();
            datos[2] = Integer.toString(LoginControlador.ListaEmpleados.get(i).getEdad());
            datos[3] = LoginControlador.ListaEmpleados.get(i).getContrasenia();
            model.addRow(datos);
            model.isCellEditable(i, 0);
            model.isCellEditable(i, 1);
            model.isCellEditable(i, 2);
            model.isCellEditable(i, 3);
            this.tabla.setModel(model);
            this.ventana.setTablaEmpleados(tabla);
        }
    }
    /**
     * Metodo para colocar los datos en las celdas para poder editarlos.
     * @param id del empleado a editar.
     * @return la posicion en el ArrayList del empleado.
     */
    public int colocarDatos(String id) {
        int indicador = 0;
        for (int i = 0; i < LoginControlador.ListaEmpleados.size(); i++) {
            if (id.equals(LoginControlador.ListaEmpleados.get(i).getID())) {
                this.ventana.setTxtID(LoginControlador.ListaEmpleados.get(i).getID());
                this.ventana.setTxtNombre(LoginControlador.ListaEmpleados.get(i).getNombre());
                this.ventana.setTxtContrasenia(LoginControlador.ListaEmpleados.get(i).getContrasenia());
                this.ventana.setTxtEdad(Integer.toString(LoginControlador.ListaEmpleados.get(i).getEdad()));
                indicador = i;
            }
        }
        return indicador;
    }
    /**
     * Metodo para convertir en un ArrayList de String los datos de todos los
     * empleados.
     * @return ArrayList de String con los datos de los empleados.
     */
    public ArrayList<String> convertirString(){
        ArrayList<String> empleados = new ArrayList<>();
        for (int i = 0; i < LoginControlador.ListaEmpleados.size(); i++) {
            String cadena = null;
            cadena = LoginControlador.ListaEmpleados.get(i).toString();
            empleados.add(cadena);
        }
        return empleados;
    }
    /**
     * Metodo para realizar los cambios solicitados por el usuario
     * en la informacion del empleado seleccionado.
     * @param id contiene el ID de empleado.
     * @param nombre contiene el nombre del empleado.
     * @param edad contiene la edad del empleado.
     */
    public void realizarCambios(int id, String nombre, int edad) {
        Archivo archivo = new Archivo();
        ArrayList<String> datos = new ArrayList<>();
        LoginControlador.ListaEmpleados.get(id).setNombre(nombre);
        LoginControlador.ListaEmpleados.get(id).setEdad(edad);
        datos = convertirString();
        archivo.escribirArchivo("Empleados.txt", datos);
    }
    /**
     * Metodo que obtiene la posicion en el arreglo del elemento solicitado.
     * @param id contiene el ID del empleado.
     * @return indicador con la posicion del empleado.
     */
    public int obtenerPosicion(String id) {
        int indi = 0;
        for (int j = 0; j < LoginControlador.ListaEmpleados.size(); j++) {
            if (id.equals(LoginControlador.ListaEmpleados.get(j).getID())) {
                indi = j;
            }
        }
        return indi;
    }
    /**
     * Se activa al presionar un botón
     * @param ae ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        //Boton para editar informacion de algun empleado
        if (this.ventana.getBtnEditar() == ae.getSource()) {
            try {
                if (this.ventana.getTxtIDEliminar().getText().length() != 0) {
                    id = this.ventana.getTxtIDEliminar().getText();
                    indicador = colocarDatos(id);
                } else {
                    throw new CampoVacio("Favor de seleccionar un articulo de la tabla.");
                }
            } catch (CampoVacio e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
        //Boton para eliminar empleado
        if (this.ventana.getBtnEliminar() == ae.getSource()) {
            try {
                if (this.ventana.getTxtIDEliminar().getText().length() != 0) {
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Realmente desea eliminar al empleado: " + this.ventana.getTxtIDEliminar().getText()+ "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (opcion == 0) {
                        id = this.ventana.getTxtIDEliminar().getText();
                        int posicion = obtenerPosicion(id);
                        LoginControlador.ListaEmpleados.remove(posicion);
                        Archivo archivo = new Archivo();
                        ArrayList<String> datos = new ArrayList<>();
                        datos = convertirString();
                        archivo.escribirArchivo("Empleados.txt", datos);
                        mostrarDatosTabla();
                    }
                } else {
                    throw new CampoVacio("Favor de seleccionar un articulo de la tabla.");
                }
            } catch (CampoVacio e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }
        //Boton para guardar cambios
        if (this.ventana.getBtnGuardar() == ae.getSource()) {
            try {
                if (this.ventana.getTxtID().getText().length() != 0) {
                    
                    String nombre = this.ventana.getTxtNombre().getText();
                    int edad = Integer.parseInt(this.ventana.getTxtEdad().getText());
                    realizarCambios(indicador, nombre, edad);
                    mostrarDatosTabla();
                } else {
                    throw new CampoVacio("Favor de seleccionar un articulo de la tabla.");
                }
            } catch (CampoVacio e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            } catch (NumberFormatException e) { 
                JOptionPane.showMessageDialog(null, "La edad tiene que ser un numero entero");
            }
        }
        //Boton para salir
        if (this.ventana.getBtnSalir() == ae.getSource()) {
            this.ventana.setVisible(false);
        }
    }
    /**
     * Metodo abstracto paara verificar a que fila de la tabla le realizaron 2
     * click y colocar el ID en el recuadro correspondiente.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseClicked(MouseEvent me) {
        if(tabla == me.getSource() && me.getClickCount() == 2){
            int filaPulsada = tabla.getSelectedRow();
            if( filaPulsada >= 0){
                String id = (String)this.tabla.getValueAt(filaPulsada, 0);
                this.ventana.setTxtIDEliminar(id);
            }
        }
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mousePressed(MouseEvent me) {
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseReleased(MouseEvent me) {
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseEntered(MouseEvent me) {
    }
    /**
     * Metodo abstracto.
     * @param me contiene la accion del boton.
     */
    @Override
    public void mouseExited(MouseEvent me) {
    }
}
