package Modelo;

/**
 * Clase que corresponde a los administrador del sistema, contiene todos los
 * atributos de un administrador.
 * @author Samantha Caamal.
 */
public class AdministradorModelo extends Usuario{
    /**
     * Contructo vacio de la clase.
     */
    public AdministradorModelo(){
    }
    /**
     * Contructor de la clase para poder instanciar.
     * @param ID contiene la clave unica del administrador.
     * @param nombre contiene el nombre del administrador.
     * @param contrasenia contiene la contrasenia para acceder a la cuenta.
     */
    public AdministradorModelo(String ID, String nombre, String contrasenia) {
        super(ID, nombre, contrasenia);
    }
    //Metodos get y set
    /**
     * Metodo heredado para establecer la contrasenia del administrador.
     * @param contrasenia contiene una cadena ingresada por el administrador.
     */    
    @Override
    public void setContrasenia(String contrasenia) {
        super.setContrasenia(contrasenia);
    }
    /**
     * Metodo heredado para obtener la contrasenia del administrador.
     * @return contrasenia contiene un string.
     */
    @Override
    public String getContrasenia() {
        return super.getContrasenia();
    }
    /**
     * Metodo heredado para establecer el nombre del administrador.
     * @param nombre contiene un string.
     */
    @Override
    public void setNombre(String nombre) {
        super.setNombre(nombre);
    }
    /**
     * Metodo heredado para obtener el nombre del administrador.
     * @return nombre del administrador.
     */
    @Override
    public String getNombre() {
        return super.getNombre();
    }
    /**
     * Metodo heredado para establecer el ID del administrador.
     * @param ID contiene un string.
     */
    @Override
    public void setID(String ID) {
        super.setID(ID);
    }
    /**
     * Metodo heredado para obtener el ID del administrador.
     * @return ID con la clave del administrador.
     */
    @Override
    public String getID() {
        return "A" + super.getID();
    }
    /**
     * Metodo para poder escribir la informacion del producto.
     * @return cadena con los datos del producto.
     */
    @Override
    public String toString() {
        return this.ID + "/" + this.nombre + "/" + this.getContrasenia();
    }
}
