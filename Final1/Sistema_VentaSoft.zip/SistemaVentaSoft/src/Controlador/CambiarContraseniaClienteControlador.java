/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Excepciones.CompararCambios;
import Excepciones.ContraseniaIncorrecta;
import Excepciones.NoCoincidenciaContrasenia;
import Modelo.Archivo;
import Modelo.ClienteModelo;
import Vista.CambiarContraseniaVista;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author ElenaMariel
 */
public class CambiarContraseniaClienteControlador implements ActionListener{
    private CambiarContraseniaVista ventana;
    private JButton guardar;
    private JButton salir;
    private String antiguaContrasenia;
    private String nuevaContrasenia;
    private String nuevaContrasenia2;
    private Archivo escribir = new Archivo();
    private ArrayList<String> dato = new ArrayList<>();
    private ClienteModelo cliente;
    
    public CambiarContraseniaClienteControlador(CambiarContraseniaVista vista, ClienteModelo cliente) {
        this.ventana = vista;
        this.cliente = cliente;
        this.ventana.setLocationRelativeTo(null);
        this.guardar = this.ventana.getBtnGuardar();
        this.ventana.getBtnGuardar().addActionListener(this);
        this.salir = this.ventana.getBtnCancelar();
        this.ventana.getBtnCancelar().addActionListener(this);
    }
    
    public void verificar(String antigua, String nueva, String nueva2){
        if(antigua.equals(cliente.getContrasenia())){
            if(nueva.equals(cliente.getContrasenia())){
                throw new CompararCambios("No se ha realizado cambios en la contraseña.");
            }else{
                if(nueva.equals(nueva2)){
                    cliente.setContrasenia(nueva);
//                    ArrayList<String> datos = new ArrayList<>();
//                    for (int i = 0; i < LoginControlador.ListaClientes.size(); i++) {
//                        String cadena = LoginControlador.ListaClientes.get(i).toString();
//                        datos.add(cadena);
//                    }
                    ArrayList<String> aux = new ArrayList<>();
                            for (int i = 0; i < LoginControlador.ListaClientes.size(); i++) {
                                aux.add(new Modelo.Convertidor().stringCliente(LoginControlador.ListaClientes.get(i)));
                            }
                    
                    escribir.escribirArchivo("Clientes.txt", aux);
                    JOptionPane.showMessageDialog(null, "Cambio guardado con éxito");
                    this.ventana.setVisible(false);
                }else{
                    throw new NoCoincidenciaContrasenia("Confirmacion incorrecta.");
                }
            }
        }else{
            throw new ContraseniaIncorrecta("Contrasenia incorrecta.");
        }
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(this.guardar == ae.getSource()){
            antiguaContrasenia = this.ventana.getTxtContraseniaAntigua().getText();
            nuevaContrasenia = this.ventana.getTxtContrasenia1().getText();
            nuevaContrasenia2 = this.ventana.getTxtContrasenia2().getText();
            try{
                verificar(antiguaContrasenia, nuevaContrasenia, nuevaContrasenia2);
            }catch(CompararCambios e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }catch(NoCoincidenciaContrasenia e1){
                JOptionPane.showMessageDialog(null, e1.getMessage());
            }catch(ContraseniaIncorrecta e2){
                JOptionPane.showMessageDialog(null, e2.getMessage());
            }
        }
        
        if(this.salir == ae.getSource()){
            this.ventana.setVisible(false);
        }
    }
    
}

