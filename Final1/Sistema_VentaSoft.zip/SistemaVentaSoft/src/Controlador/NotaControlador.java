/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.*;
import Vista.NotaVista;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.*;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Alex
 */
public class NotaControlador implements ActionListener, ItemListener, KeyListener {

    /**
     * el total de la compra
     */
    private double total;
    /**
     * La vista de la nota
     */
    private NotaVista nV;

    /**
     * El modelo de la nota
     */
    private NotaModelo nota;
    /**
     * El cliente que compra
     */
    private ClienteModelo clienteS;
    /**
     * Ajusta la vista de la nota e inicializa los valores, además de que agrega
     * a los objetos sus eventos correspondientes
     *
     * @param nV NotaVista
     * @param nota NotaModelo
     */
    public NotaControlador(NotaVista nV, NotaModelo nota) {
        this.nV = nV;
        this.nV.setLocationRelativeTo(null);
        this.nota = nota;
        this.total = 0;
        this.clienteS = null;
        
//        nV.getTxtVendedor().setText(nota.getEmpleado().getNombre());
        nV.getTxtVendedor().setText(LoginControlador.ListaEmpleados.get(LoginControlador.indicadorUsuario).getNombre());
        nV.getTxtFecha().setValue(nota.getFecha());
        nV.getTxtNumFact().setText(String.valueOf(nota.getNumNota()));
        nV.getBtnFactura().setEnabled(false);
        nV.getBtnCancelar().addActionListener(this);
        nV.getBtnBuscar().addActionListener(this);
        nV.getComBoxPago().addItemListener(this);
        nV.getTxtCantidad().addKeyListener(this);
        nV.getBtnPagar().addActionListener(this);
        nV.getBtnFactura().addActionListener(this);

        nV.getjTable1().setModel(defTableModel(nota.getProductos()));

        total();

        nV.setLocationRelativeTo(null);
        nV.getjTable1().setEnabled(false);
        nV.getjTable1().setAutoCreateRowSorter(true);
        nV.setTitle("Nota");
//        nV.setVisible(true);
    }

    /**
     * Selecciona que accion se realizo, en otras palabras, que fue lo que se
     * presiono, para invocar una accion.
     *
     * @param ae ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (nV.getBtnCancelar() == ae.getSource()) {
            nV.dispose();

        } else {
            if (nV.getComBoxPago() == ae.getSource()) {
                nV.getTxtCantidad().setEnabled(false);

            } else {
                if (nV.getBtnBuscar() == ae.getSource()) {
                    if (!nV.getTxtIngreseCliente().getText().isEmpty()) {
                        ClienteModelo c = buscarCliente(LoginControlador.ListaClientes);
                        if (c != null) {
                            clienteS = c;
                            addDatosCliente((ClienteModelo) c);
                        } else {
                            JOptionPane.showMessageDialog(null, "Cliente no encontrado");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Campo vacío");
                    }

                } else {
                    if (nV.getBtnPagar() == ae.getSource()) {
                        //Código para agregarselo a empleado y cliente
                        /*Cuando le de pagar se va a buscar el producto que tiene con 
                        el original por ID, cuando lo encuentre, se tiene que restar 
                        la cantidad en stock con la que compró el cliente y se actualiza la tabla*/
                        if (!nV.getTxtCodigo().getText().isEmpty() && !nV.getTxtCambio().getText().isEmpty()) {
                            LoginControlador.ListaEmpleados.get(LoginControlador.indicadorUsuario).getNotas().add(nota);
                            clienteS.getNotas().add(nota);
//                            nota.getEmpleado().getNotas().add(nota);
                            ArrayList<String> aux = new ArrayList<>();
                            for (int i = 0; i < LoginControlador.ListaEmpleados.size(); i++) {
                                aux.add(new Modelo.Convertidor().empleadoString(LoginControlador.ListaEmpleados.get(i)));
                            }
                            new Modelo.Archivo().escribirArchivo("Empleados.txt", aux);
                            
                            ArrayList<String> aux2 = new ArrayList<>();
                            for (int i = 0; i < LoginControlador.ListaClientes.size(); i++) {
                                aux2.add(new Modelo.Convertidor().stringCliente(LoginControlador.ListaClientes.get(i)));
                            }
                            new Modelo.Archivo().escribirArchivo("Clientes.txt", aux2);
                            
                            nota.masUno();
                            for (int i = 0; i < nota.getProductos().size(); i++) {
//                            nota.getProductos().get(i);
                            for (int j = 0; j < LoginControlador.ListaProductos.size(); j++) {
                                System.out.println(nota.getProductos().get(i).getIdProducto());
                                System.out.println(LoginControlador.ListaProductos.get(j).getIdProducto());
                                if(nota.getProductos().get(i).getIdProducto().equals(LoginControlador.ListaProductos.get(j).getIdProducto())){
                                    int can = LoginControlador.ListaProductos.get(j).getCantidad() 
                                            -nota.getProductos().get(i).getCantidad();
                                    System.out.println(can);
                                    LoginControlador.ListaProductos.get(j).setCantidad(can);
                                    
                                }
                            }
                        }
                        ArrayList<String> nuevo = new ArrayList<>();
                        for (ProductoModelo ListaProducto : LoginControlador.ListaProductos) {
                            nuevo.add(ListaProducto.toString());
                        }
                        new Archivo().escribirArchivo("Productos.txt", nuevo);
                            
                            //Guardar empleado y sus notas
                            JOptionPane.showMessageDialog(null, "Pago exitoso");
                            nV.getBtnFactura().setEnabled(true);
                            nV.getBtnPagar().setEnabled(false);
                        } else {
                            JOptionPane.showMessageDialog(null, "Datos incompletos");
                        }
                    } else {
                        if (nV.getBtnFactura() == ae.getSource()) {
                            Print print = new Print(nV,nota.getProductos());
                            print.im();
                          nV.setVisible(false);
                        }
                    }
                }
            }
        }
    }

    /**
     * Busca el cliente a traves del id/nombre que se espeficique en el
     * textField de busqueda
     *
     * @param cliente ArrayList de tipo ClienteModelo
     * @return ClienteModelo que coincida con la busqueda
     */
    private ClienteModelo buscarCliente(ArrayList<ClienteModelo> cliente) {
        List<ClienteModelo> lista = new ArrayList<>();
        Object s = null;
        for (int i = 0; i < cliente.size(); i++) {
            if (cliente.get(i).getNombre().equals(nV.getTxtIngreseCliente().getText())) {
//                String codigo = cliente.get(i).getID();
//                String nombre = cliente.get(i).getNombre();
//                int telefono = cliente.get(i).getTelefono();
//                String direccion = cliente.get(i).getDireccion();
//                lista.add(new ClienteModelo(codigo.substring(1), nombre, telefono, direccion));
                lista.add(cliente.get(i));
                s = lista.get(lista.size() - 1);
            }

        }
        ArrayList<String> aux = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            aux.add("ID: " + lista.get(i).getID() + ", Edad: " + lista.get(i).edad + ", Telefono: " + lista.get(i).telefono);
        }
        if (lista.size() > 1) {
            Object[] nul = aux.toArray();

            s = JOptionPane.showInputDialog(null, "Escoja", "Clientes",
                    JOptionPane.QUESTION_MESSAGE, null, nul, null);
            int i = 0;
            boolean flag = false;
            while (i < lista.size() && !flag) {
                if (String.valueOf(s).equals(aux.get(i))) {
                    s = lista.get(i);
                    flag = true;
                }
                i++;
            }

        }

        return (ClienteModelo) s;
    }

    /**
     * Verifica los subtotales de cada producto y los suma para agregarlo al
     * total, en un textField
     */
    private void total() {
        int filas = nV.getjTable1().getModel().getRowCount();
        for (int j = 0; j < filas; j++) {
            total += Double.parseDouble(String.valueOf(nV.getjTable1().getModel().getValueAt(j, 4)));
        }
        nV.getTxtTotal().setText(String.valueOf(total));
    }

    /**
     * Selecciona cual item esta actualmente puesto y con base en su indice se
     * determina que accion hacer, si es 1 se eligio la tarjeta, si es diferente
     * entonces fue el efectivo
     *
     * @param ie ItemEvent
     */
    @Override
    public void itemStateChanged(ItemEvent ie) {

        if (nV.getComBoxPago().getSelectedIndex() == 1) {
            nV.getTxtCantidad().setEnabled(false);
            nV.getTxtCantidad().setText(String.valueOf(total));
            nV.getTxtCambio().setText("0.0");
        } else {
            nV.getTxtCantidad().setEnabled(true);
        }
    }

    /**
     * Se presiona cuando se escribe una tecla
     *
     * @param ke KeyEvent
     */
    @Override
    public void keyTyped(KeyEvent ke) {

    }

    /**
     * Se activa cuando se presiona una tecla
     *
     * @param ke KeyEvent
     */
    @Override
    public void keyPressed(KeyEvent ke) {
    }

    /**
     * Se activa cuando se libera una tecla
     *
     * @param ke KeyEvent
     */
    @Override
    public void keyReleased(KeyEvent ke) {
        if (nV.getTxtCantidad() == ke.getSource()) {
            cambio();
        }
    }

    /**
     * Captura el valor que se encuentra en el textField de Cantitdad y lo usa
     * para sacar el cambio del cliente
     */
    private void cambio() {
        //CATCH Por si no entra un número
        try {
            double dinero = Double.parseDouble(nV.getTxtCantidad().getText());
            double cambio = dinero - total;
            if (cambio >= 0) {
                nV.getTxtCambio().setText(String.valueOf(cambio));
            } else {
                nV.getTxtCambio().setText("");
            }
        } catch (NumberFormatException e) {
            nV.getTxtCambio().setText("");
        }
    }

    /**
     * Agrega los valores del cliente a la vista
     *
     * @param cliente ClienteModelo
     */
    private void addDatosCliente(ClienteModelo cliente) {
        nV.getTxtCodigo().setText(cliente.getID());
        nV.getTxtNombre().setText(cliente.getNombre());
        nV.getTxtTelefono().setText(String.valueOf(cliente.getTelefono()));
        nV.getTxtDireccion().setText(cliente.getDireccion());
    }

    /**
     * Recibe un arreglo que descompone y ajusta en un DefaultTableModel
     *
     * @param s ArrayList de tipo ProductoModelo
     * @return regresa un DefaultTableModel con los datos del arreglo
     */
    private DefaultTableModel defTableModel(ArrayList<ProductoModelo> s) {
        DefaultTableModel aux = (DefaultTableModel) nV.getjTable1().getModel();
        for (int i = 0; i < s.size(); i++) {
            String id = s.get(i).getIdProducto();
            String des = s.get(i).getDescripcion();
            int can = s.get(i).getCantidad();
            double prix = s.get(i).getPrecioUnitario();
            double sub = can * prix;
//            double sub = s.get(i).getImporte();
            aux.addRow(new Object[]{id, des, can, prix, sub});
        }
        return aux;
    }

    /**
     * Selecciona el jframe y lo imprime
     */
    private void imprimir() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Print Data");

        job.setPrintable(new Printable() {
            public int print(Graphics pg, PageFormat pf, int pageNum) {
                pf.setOrientation(PageFormat.LANDSCAPE);
                if (pageNum > 0) {
                    return Printable.NO_SUCH_PAGE;
                }

                Graphics2D g2 = (Graphics2D) pg;
                g2.translate(pf.getImageableX(), pf.getImageableY());
                g2.scale(0.24, 0.24);
                nV.getjPanel1().paint(g2);
//          

                return Printable.PAGE_EXISTS;

            }
        });

        boolean ok = job.printDialog();
        if (ok) {
            try {

                job.print();
            } catch (PrinterException ex) {
            }
        }
    }
}
